package Crossbrowsertesting;

import java.net.MalformedURLException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
public class openbrowserclass {
	


	  private WebDriver driver;

	  @Test
	  public void testCaseOne() {
	    driver.get("http://www.google.com");
	    driver.close();
	  } 

	  @BeforeMethod
	  @Parameters("browser")
	  public void beforeMethod(String browser) throws MalformedURLException {
	    if (browser.equalsIgnoreCase("chrome")) {
	        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
	        driver = (WebDriver) new ChromeDriver();

	    } else if (browser.equalsIgnoreCase("firefox")) {
	    	System.setProperty("webdriver.gecko.driver", "C:\\FirefoxDriver\\geckodriver.exe");
	        driver = (WebDriver) new FirefoxDriver();
	        

		} /*
			 * else if (browser.equalsIgnoreCase("ie")) {
			 * System.setProperty("webdriver.ie.driver", "C:\\IEDriver\\iedriver.exe");
			 * driver = new InternetExplorerDriver();
			 * 
			 * } else if (browser.equalsIgnoreCase("safari")) { driver = new SafariDriver();
			 * }
			 */
	}

	  @AfterMethod
	  public void afterMethod() {
	    driver.quit();
	  }

	}

